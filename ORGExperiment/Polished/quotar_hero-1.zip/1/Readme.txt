Version: 1

A contender in modfest 37

This release only contains 2 completed songs, though more are quite easy to add.
For photosensitive players, it may be necessary to turn off lighting effects in settings. I don't believe the effects are extreme, but this is a CYA warning.

Default controls use keys '1', '2', '3', '4' for the corresponding notes on the note highway, but these can (and probably should) be rebound in the settings.

Credits (where due):
Pixel: The original Cave Story game
Alula: d-rs engine
Dr_Glaucous: everything that's left over

Song Credits:
Stadium Rave A: Mark Governor
Space Debris: Markus "The Captain" Kaarlonen




