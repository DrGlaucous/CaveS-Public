

//#[macro_use]
//extern crate log;

#[macro_use]
pub mod libretro;
mod core;




