Version: 1

A contender in modfest 39

A short mod showcasing the use of 3D in a Cave Story Engine.

Tips:
Use L-Shift to run faster. (This mod has a lot of walking)


Credits (where due):
Pixel: The original Cave Story game
Alula: d-rs engine
Modarchive: Tracker music
Dr_Glaucous: everything that's left over






