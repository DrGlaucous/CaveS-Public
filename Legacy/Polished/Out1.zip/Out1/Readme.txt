Unpolished version.

You shouldn't really be playing this one, though it does work.

Use "LShift" to sprint. This can be rebound.