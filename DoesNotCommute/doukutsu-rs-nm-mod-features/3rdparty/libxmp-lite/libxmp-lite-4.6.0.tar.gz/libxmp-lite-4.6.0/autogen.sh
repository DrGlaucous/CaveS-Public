#!/bin/sh

autoconf
