<Does Not Commute (Cave Story Edition) Version 1.0.3.2 ~ 2022>
This mod is based on the hit mobile game, [Does not] Commute by mediocre,
a game where the player must drive cars to specific destinations within a time limit all while avoiding the cars they have driven previously.

This game follows a similar idea, with the player traveling to destinations within each map while needing to
beat the timer and avoid friendly fire from their previous playthroughs.

Several things to note:
Any RED tinted bullet CAN hurt the player, so watch out.

The small blinking clocks give the player a time bonus. The time they give varies, so be sure to get the hard to reach ones.




Credits (where credit is due):

Pixel: The original Cave Story game
Alula et.al.: d-rs
<modarchive.org>: Delightful tracker music
Dr_Glaucous: everything that's left over




Note: We're open source now!
https://github.com/DrGlaucous/CaveS-Public/tree/main/DoesNotCommute