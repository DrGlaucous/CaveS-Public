<Does Not Commute (Cave Story Edition) Version 2.0.0.3 ~ 2024>
This mod is based on the hit mobile game, [Does not] Commute by mediocre,
a game where the player must drive cars to specific destinations within a time limit all while avoiding the cars they have driven previously.

This game follows a similar idea, with the player traveling to destinations within each map while needing to
beat the timer and avoid friendly fire from their previous playthroughs.

Several things to note:
- Any RED tinted bullet CAN hurt the player, so watch out.
- The small blinking clocks give the player a time bonus. The time they give varies, so be sure to get the hard to reach ones.
- Use "Q" to skip through dialouge and cutscenes


====Changelog====
2.0.0.3:
- Fixed several TSC bugs and spelling mistakes
- Changed tracker backends from Oxdz to libxmp-lite (much better quality)
- Fixed menu scroll bugs
- Strultz Mode



Credits (where credit is due):

====Version 2 (d-rs)====
Pixel: The original Cave Story game
Alula et.al.: d-rs
<modarchive.org>: Delightful tracker music
Dr_Glaucous: everything that's left over

====Version 1 (CSE2)====
Clownancy/CuckyDev + whoever else: The (ooo contraband) CSE2 Engine
Aar: Action Gamemaster sprite
2DBro: Fantastic ORG music (I may/may not have ripped from one of his mods, I don't know the actual names of the songs, though. They just sound neat.), and the Headman Sprite, 





Note: We're open source now!
https://github.com/DrGlaucous/CaveS-Public/tree/main/DoesNotCommute