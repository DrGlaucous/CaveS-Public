Version: 1

A contender in modfest 38


Note: for less glitches and smoother gameplay, run the game in 60TPS (CS+) mode, adjusted in the settings
Tip: Slopes do not halt sideways momenum, making them "Slippery". Seek out flat blocks to hook onto whenever possible.


Credits (where due):
Pixel: The original Cave Story game
Alula: d-rs engine
Matt Christensen: Music Composer (Lifted from the game Superliminal)
Dr_Glaucous: everything that's left over


Find the source code here:
https://github.com/DrGlaucous/CaveS-Public/tree/main/GetOutOfIt


