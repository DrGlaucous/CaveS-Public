pub struct Config {
    pub title: String,
    
    pub window_width: u32,
    pub window_height: u32,
    
    pub pixels_per_unit: f32,
}