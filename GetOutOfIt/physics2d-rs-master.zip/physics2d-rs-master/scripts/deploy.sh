#!/usr/bin/env sh

cargo login $CARGO_TOKEN

cargo publish
