<60 Seconds Mahin Run Version: 1 ~ 2024>

A contender in Modfest 40 (happy 20th anniversary, Cave Story!)



Guide Mahin to the Mahin restaurant before it closes in 60 seconds.
The game uses 3 buttons for control by default: Left, Right, and Up/Z (for jumping, either works).

In case it wasn't apparent, this mod is heavily inspired by "60 Seconds Burger Run", a staple of the flash games that were available on sites like CoolMath.com.
(It's popular enough to have a dedicated speedrunning community if that says anything)

Credits (where credit is due):
Pixel: The original Cave Story game
Alula et.al.: d-rs
Jakim: the song "mindjunk", sourced from <modarchive.org> (https://modarchive.org/index.php?request=view_profile&query=69513)
Dr_Glaucous: everything that's left over


