# `howto` example

This example is meant to showcase common actions within `glow`.

# How to Build

```shell
cargo run
```
